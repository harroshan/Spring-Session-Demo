package spring.tutorial.spring_session;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}

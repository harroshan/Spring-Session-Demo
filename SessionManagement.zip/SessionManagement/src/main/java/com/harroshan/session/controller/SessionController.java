package com.harroshan.session.controller;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SessionController {

	@GetMapping("/")
	public String getMain(HttpSession session) {
		long ss = session.getCreationTime();
		String ii = session.getId();
		System.out.println(ii + "      " + ss);
		return session.getId();
	}

}
